# SwiftDrop — Task

## 🚀 Welcome to SwiftDrop

You just joined **SwiftDrop** as a Junior Backend Developer.
The frontend is ready, but the API endpoints are empty.
**Check the Presentation Slides** for the detailed requirements.

---

## ⚡ Quick Start

```bash
pip install -r requirements.txt
uvicorn main:app --reload
```

- **API Docs:** http://127.0.0.1:8000/docs
- **Frontend:** Open `frontend/index.html` in your browser

---

## 📁 Project Files

| File | What to do |
|------|-----------|
| `main.py` | ✏️ Complete Tickets 1-4 here |
| `utils.py` | ✏️ Complete Bonus 1 & 2 here |
| `fake_db.py` | ❌ Don't modify |
| `schemas.py` | ❌ Don't modify |

---

## 📋 Tickets

| # | Ticket | Topics |
|---|--------|--------|
| 1 | Get Package Details | Path Params, Error Handling |
| 2 | List & Filter Packages | Query Params, CRUD (Read) |
| 3 | Create Package | Pydantic, Custom Response (201) |
| 4 | Update Delivery Status | CRUD (Update), Business Logic |
| 🌟 | Bonus #1: Detect Duplicates | HashMap, O(n²) → O(n) |
| 🌟 | Bonus #2: Max Deliveries | Greedy Algorithm, Scheduling |

---

## 📚 Available Helpers

```python
fake_db.get_all_packages()        → list[dict]
fake_db.get_package_by_id(id)     → dict | None
fake_db.save_package(data)        → dict
fake_db.update_package(id, data)  → dict | None
fake_db.get_all_couriers()        → list[dict]
fake_db.get_available_couriers()  → list[dict]

calculate_distance(lat1, lon1, lat2, lon2)  → float (km)
VALID_TRANSITIONS  → dict[str, set[str]]
```
