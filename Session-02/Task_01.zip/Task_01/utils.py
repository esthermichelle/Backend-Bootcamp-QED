"""
SwiftDrop — Utility Functions
==============================
STUDENTS: You need to modify TWO functions in this file (Bonus tickets):
  1. find_duplicates_optimized()   → Bonus #1
  2. select_max_deliveries_optimized() → Bonus #2
Everything else is ready to use.
"""

import math
import time


# ═══════════════════════════════════════════════════════════════
# DISTANCE CALCULATION — Ready to use
# ═══════════════════════════════════════════════════════════════

def calculate_distance(lat1: float, lon1: float, lat2: float, lon2: float) -> float:
    """Calculate distance between two GPS coordinates in kilometers."""
    R = 6371
    dlat = math.radians(lat2 - lat1)
    dlon = math.radians(lon2 - lon1)
    a = (math.sin(dlat / 2) ** 2 +
         math.cos(math.radians(lat1)) * math.cos(math.radians(lat2)) *
         math.sin(dlon / 2) ** 2)
    c = 2 * math.atan2(math.sqrt(a), math.sqrt(1 - a))
    return round(R * c, 2)


# ═══════════════════════════════════════════════════════════════
# STATUS TRANSITION RULES — Ready to use
# ═══════════════════════════════════════════════════════════════

VALID_TRANSITIONS: dict[str, set[str]] = {
    "pending":    {"assigned", "cancelled"},
    "assigned":   {"picked_up", "cancelled"},
    "picked_up":  {"in_transit", "cancelled"},
    "in_transit": {"delivered", "cancelled"},
    "delivered":  set(),
    "cancelled":  set(),
}


# ═══════════════════════════════════════════════════════════════
# TIME HELPER — Ready to use
# ═══════════════════════════════════════════════════════════════

def parse_time(time_str: str) -> int:
    """Convert 'HH:MM' string to minutes since midnight.
    Example: '14:30' → 870 minutes
    """
    h, m = map(int, time_str.split(':'))
    return h * 60 + m


# ═══════════════════════════════════════════════════════════════
# BONUS #1: DUPLICATE DETECTION
# ═══════════════════════════════════════════════════════════════

DUPLICATE_WINDOW_SECONDS = 300  # 5 minutes


def find_duplicates_naive(packages: list[dict]) -> list[tuple[int, int]]:
    """⚠️ SLOW VERSION (O(n²)) — DO NOT MODIFY.
    Compares every package against every other package.
    A "duplicate" = same sender + same recipient + same weight, within 5 minutes.
    """
    duplicates = []
    for i in range(len(packages)):
        for j in range(i + 1, len(packages)):
            p1, p2 = packages[i], packages[j]

            if (p1["sender_name"] == p2["sender_name"]
                and p1["recipient_name"] == p2["recipient_name"]
                and p1["weight_kg"] == p2["weight_kg"]
                and abs((p1["created_at"] - p2["created_at"]).total_seconds()) <= DUPLICATE_WINDOW_SECONDS):
                duplicates.append((p1["id"], p2["id"]))
    return duplicates


def find_duplicates_optimized(packages: list[dict]) -> list[tuple[int, int]]:
    """
    🎯 BONUS #1 — YOUR CODE HERE
    Same result as find_duplicates_naive() but in O(n) using a HashMap.
    Hint: Group by (sender_name, recipient_name, weight_kg), then compare only within groups.
    """
    # ❌ DELETE THIS LINE and write your solution:
    return find_duplicates_naive(packages)


def benchmark_duplicate_detection(packages: list[dict]) -> dict:
    """Benchmark: compares naive vs optimized speed."""
    start = time.time()
    naive_result = find_duplicates_naive(packages)
    naive_time = time.time() - start

    start = time.time()
    optimized_result = find_duplicates_optimized(packages)
    optimized_time = time.time() - start

    correct = set(naive_result) == set(optimized_result)
    speedup = naive_time / optimized_time if optimized_time > 0 else 0

    return {
        "naive_time_ms": round(naive_time * 1000, 2),
        "optimized_time_ms": round(optimized_time * 1000, 2),
        "speedup": f"{speedup:.1f}x",
        "correct": correct,
        "duplicates_found": len(optimized_result),
        "dataset_size": len(packages),
        "passed": correct and speedup >= 5,
    }


# ═══════════════════════════════════════════════════════════════
# BONUS #2: MAX DELIVERIES SCHEDULING (Interval Scheduling)
# ═══════════════════════════════════════════════════════════════
#
# Scenario: A courier has 6 delivery requests for today.
# Each has a time window (start -> end). Some overlap.
# Find the MAXIMUM number of deliveries they can do
# without any time conflicts.
#
# Example:
#   Delivery A: 09:00 -> 11:00
#   Delivery B: 09:30 -> 10:30  (overlaps with A)
#   Delivery C: 10:30 -> 12:00  (overlaps with A)
#   Delivery D: 12:00 -> 13:00
#
#   Naive picks A first (it's first), skips B and C (overlap), picks D -> 2 deliveries
#   Optimal sorts by end time: picks B, C, D -> 3 deliveries (more money!)
# ═══════════════════════════════════════════════════════════════


def select_max_deliveries_naive(slots: list[dict]) -> list[dict]:
    """⚠️ SLOW VERSION (O(n²)) — DO NOT MODIFY.
    Tries every combination to find max non-overlapping set.
    For each slot, checks against all previously selected slots.
    Picks in input order (not optimal).
    """
    selected = []
    for slot in slots:
        s_start = parse_time(slot["start"])
        s_end = parse_time(slot["end"])

        conflict = False
        for picked in selected:
            p_start = parse_time(picked["start"])
            p_end = parse_time(picked["end"])
            if s_start < p_end and p_start < s_end:
                conflict = True
                break

        if not conflict:
            selected.append(slot)

    return selected


def select_max_deliveries_optimized(slots: list[dict]) -> list[dict]:
    """
    🎯 BONUS #2 — YOUR CODE HERE

    Return the maximum number of non-overlapping delivery slots.

    Hint: The Greedy Algorithm for Interval Scheduling:
      1. Sort all slots by END TIME (earliest end first)
      2. Pick the first one
      3. For each next slot: if it starts AFTER the last picked one ends → pick it
      4. Return the picked slots

    Why this works: By always picking the slot that ends earliest,
    you leave the most room for future slots.
    """
    # ❌ DELETE THIS LINE and write your solution:
    return select_max_deliveries_naive(slots)


def benchmark_scheduling(slots: list[dict]) -> dict:
    """Benchmark: compares naive vs optimized scheduling."""
    start = time.time()
    naive_result = select_max_deliveries_naive(slots)
    naive_time = time.time() - start

    start = time.time()
    optimized_result = select_max_deliveries_optimized(slots)
    optimized_time = time.time() - start

    return {
        "naive_count": len(naive_result),
        "optimized_count": len(optimized_result),
        "naive_time_ms": round(naive_time * 1000, 2),
        "optimized_time_ms": round(optimized_time * 1000, 2),
        "optimized_is_better": len(optimized_result) >= len(naive_result),
    }
