"""
SwiftDrop — Mock Database Layer
================================
This file simulates a database using in-memory Python data structures.
In a real project, this would be replaced by SQLAlchemy/SQLModel models
and a PostgreSQL/MySQL connection.

STUDENTS: Do NOT modify this file. Use the helper functions below in your endpoints.

All functions have docstrings — read them to understand inputs and outputs.
"""

from datetime import datetime, timedelta
import random
import copy

# ═══════════════════════════════════════════════════════════════
# MOCK DATA
# ═══════════════════════════════════════════════════════════════

_packages: list[dict] = [
    {
        "id": 1,
        "tracking_code": "SD-00001",
        "sender_name": "Ahmed Hassan",
        "sender_phone": "+201012345678",
        "recipient_name": "Sara Mohamed",
        "recipient_address": "15 Tahrir St, Downtown",
        "city": "Cairo",
        "pickup_lat": 30.0444,
        "pickup_lon": 31.2357,
        "delivery_lat": 30.0480,
        "delivery_lon": 31.2400,
        "weight_kg": 2.5,
        "description": "Electronics - Laptop charger",
        "fragile": True,
        "priority": "express",
        "status": "pending",
        "assigned_courier_id": None,
        "created_at": datetime.now() - timedelta(hours=3),
    },
    {
        "id": 2,
        "tracking_code": "SD-00002",
        "sender_name": "Omar Ali",
        "sender_phone": "+201098765432",
        "recipient_name": "Nour Hassan",
        "recipient_address": "22 Corniche Rd, Gleem",
        "city": "Alexandria",
        "pickup_lat": 31.2001,
        "pickup_lon": 29.9187,
        "delivery_lat": 31.2150,
        "delivery_lon": 29.9500,
        "weight_kg": 1.0,
        "description": "Documents - University papers",
        "fragile": False,
        "priority": "standard",
        "status": "in_transit",
        "assigned_courier_id": 2,
        "created_at": datetime.now() - timedelta(hours=5),
    },
    {
        "id": 3,
        "tracking_code": "SD-00003",
        "sender_name": "Fatma Youssef",
        "sender_phone": "+201155544433",
        "recipient_name": "Khaled Mostafa",
        "recipient_address": "8 Nile Tower, Maadi",
        "city": "Cairo",
        "pickup_lat": 29.9602,
        "pickup_lon": 31.2569,
        "delivery_lat": 29.9700,
        "delivery_lon": 31.2600,
        "weight_kg": 8.0,
        "description": "Books - Engineering textbooks",
        "fragile": False,
        "priority": "standard",
        "status": "delivered",
        "assigned_courier_id": 1,
        "created_at": datetime.now() - timedelta(days=1),
    },
    {
        "id": 4,
        "tracking_code": "SD-00004",
        "sender_name": "Youssef Tarek",
        "sender_phone": "+201234567890",
        "recipient_name": "Mona Adel",
        "recipient_address": "5 Smart Village, 6th October",
        "city": "Giza",
        "pickup_lat": 30.0131,
        "pickup_lon": 31.2089,
        "delivery_lat": 30.0700,
        "delivery_lon": 31.0200,
        "weight_kg": 0.3,
        "description": "Jewelry - Gold necklace",
        "fragile": True,
        "priority": "same_day",
        "status": "picked_up",
        "assigned_courier_id": 3,
        "created_at": datetime.now() - timedelta(hours=1),
    },
    {
        "id": 5,
        "tracking_code": "SD-00005",
        "sender_name": "Layla Mahmoud",
        "sender_phone": "+201111222333",
        "recipient_name": "Hassan Emad",
        "recipient_address": "10 El Nasr Rd, Nasr City",
        "city": "Cairo",
        "pickup_lat": 30.0626,
        "pickup_lon": 31.3400,
        "delivery_lat": 30.0700,
        "delivery_lon": 31.3450,
        "weight_kg": 15.0,
        "description": "Furniture - Small desk lamp",
        "fragile": True,
        "priority": "standard",
        "status": "pending",
        "assigned_courier_id": None,
        "created_at": datetime.now() - timedelta(hours=2),
    },
    {
        "id": 6,
        "tracking_code": "SD-00006",
        "sender_name": "Ahmed Hassan",
        "sender_phone": "+201012345678",
        "recipient_name": "Sara Mohamed",
        "recipient_address": "15 Tahrir St, Downtown",
        "city": "Cairo",
        "pickup_lat": 30.0444,
        "pickup_lon": 31.2357,
        "delivery_lat": 30.0480,
        "delivery_lon": 31.2400,
        "weight_kg": 2.5,
        "description": "Electronics - Laptop charger",
        "fragile": True,
        "priority": "express",
        "status": "pending",
        "assigned_courier_id": None,
        "created_at": datetime.now() - timedelta(hours=3, minutes=2),  # 2 min after pkg #1 — DUPLICATE!
    },
    {
        "id": 7,
        "tracking_code": "SD-00007",
        "sender_name": "Tarek Nabil",
        "sender_phone": "+201099887766",
        "recipient_name": "Dina Samir",
        "recipient_address": "3 El Horreya St, Smouha",
        "city": "Alexandria",
        "pickup_lat": 31.2100,
        "pickup_lon": 29.9400,
        "delivery_lat": 31.2200,
        "delivery_lon": 29.9550,
        "weight_kg": 4.5,
        "description": "Clothing - Winter jacket",
        "fragile": False,
        "priority": "express",
        "status": "assigned",
        "assigned_courier_id": 4,
        "created_at": datetime.now() - timedelta(hours=4),
    },
    {
        "id": 8,
        "tracking_code": "SD-00008",
        "sender_name": "Mariam Sayed",
        "sender_phone": "+201566778899",
        "recipient_name": "Ali Fouad",
        "recipient_address": "Dreamland, 6th October",
        "city": "Giza",
        "pickup_lat": 30.0200,
        "pickup_lon": 31.1500,
        "delivery_lat": 30.0500,
        "delivery_lon": 31.0000,
        "weight_kg": 25.0,
        "description": "Equipment - Camera gear",
        "fragile": True,
        "priority": "same_day",
        "status": "in_transit",
        "assigned_courier_id": 5,
        "created_at": datetime.now() - timedelta(hours=6),
    },
    {
        "id": 9,
        "tracking_code": "SD-00009",
        "sender_name": "Youssef Tarek",
        "sender_phone": "+201234567890",
        "recipient_name": "Mona Adel",
        "recipient_address": "5 Smart Village, 6th October",
        "city": "Giza",
        "pickup_lat": 30.0131,
        "pickup_lon": 31.2089,
        "delivery_lat": 30.0700,
        "delivery_lon": 31.0200,
        "weight_kg": 0.3,
        "description": "Jewelry - Gold necklace",
        "fragile": True,
        "priority": "same_day",
        "status": "pending",
        "assigned_courier_id": None,
        "created_at": datetime.now() - timedelta(hours=1, minutes=3),  # 3 min after pkg #4 — DUPLICATE!
    },
    {
        "id": 10,
        "tracking_code": "SD-00010",
        "sender_name": "Rania Khaled",
        "sender_phone": "+201377889900",
        "recipient_name": "Mohamed Ashraf",
        "recipient_address": "15 Canal St, Ismailia",
        "city": "Ismailia",
        "pickup_lat": 30.5965,
        "pickup_lon": 32.2715,
        "delivery_lat": 30.6000,
        "delivery_lon": 32.2800,
        "weight_kg": 3.0,
        "description": "Food - Homemade cookies",
        "fragile": True,
        "priority": "express",
        "status": "cancelled",
        "assigned_courier_id": None,
        "created_at": datetime.now() - timedelta(days=2),
    },
    {
        "id": 11,
        "tracking_code": "SD-00011",
        "sender_name": "Heba Fathy",
        "sender_phone": "+201044556677",
        "recipient_name": "Amr Gamal",
        "recipient_address": "7 El Gomhoreya St, Tanta",
        "city": "Tanta",
        "pickup_lat": 30.7865,
        "pickup_lon": 31.0004,
        "delivery_lat": 30.7900,
        "delivery_lon": 31.0050,
        "weight_kg": 6.0,
        "description": "Medicine - Prescription drugs",
        "fragile": True,
        "priority": "same_day",
        "status": "delivered",
        "assigned_courier_id": 2,
        "created_at": datetime.now() - timedelta(days=1, hours=5),
    },
    {
        "id": 12,
        "tracking_code": "SD-00012",
        "sender_name": "Nada Sherif",
        "sender_phone": "+201288990011",
        "recipient_name": "Karim Wael",
        "recipient_address": "20 Zamalek Tower, Zamalek",
        "city": "Cairo",
        "pickup_lat": 30.0600,
        "pickup_lon": 31.2200,
        "delivery_lat": 30.0650,
        "delivery_lon": 31.2250,
        "weight_kg": 1.5,
        "description": "Art - Framed painting",
        "fragile": True,
        "priority": "express",
        "status": "pending",
        "assigned_courier_id": None,
        "created_at": datetime.now() - timedelta(minutes=30),
    },
]

_couriers: list[dict] = [
    {
        "id": 1,
        "name": "Mohamed Reda",
        "phone": "+201155000111",
        "vehicle_type": "motorcycle",
        "current_location": "Downtown, Cairo",
        "current_lat": 30.0500,
        "current_lon": 31.2350,
        "status": "available",
        "rating": 4.8,
        "total_deliveries": 342,
    },
    {
        "id": 2,
        "name": "Mahmoud Salem",
        "phone": "+201155000222",
        "vehicle_type": "car",
        "current_location": "Gleem, Alexandria",
        "current_lat": 31.2050,
        "current_lon": 29.9250,
        "status": "busy",
        "rating": 4.5,
        "total_deliveries": 128,
    },
    {
        "id": 3,
        "name": "Samir Adel",
        "phone": "+201155000333",
        "vehicle_type": "motorcycle",
        "current_location": "Maadi, Cairo",
        "current_lat": 30.0300,
        "current_lon": 31.2100,
        "status": "busy",
        "rating": 4.9,
        "total_deliveries": 512,
    },
    {
        "id": 4,
        "name": "Tamer Hosny",
        "phone": "+201155000444",
        "vehicle_type": "bicycle",
        "current_location": "Stanley, Alexandria",
        "current_lat": 31.2150,
        "current_lon": 29.9500,
        "status": "busy",
        "rating": 4.2,
        "total_deliveries": 89,
    },
    {
        "id": 5,
        "name": "Amr Diab",
        "phone": "+201155000555",
        "vehicle_type": "van",
        "current_location": "Heliopolis, Cairo",
        "current_lat": 30.0100,
        "current_lon": 31.1800,
        "status": "busy",
        "rating": 4.7,
        "total_deliveries": 267,
    },
    {
        "id": 6,
        "name": "Hassan El-Shafei",
        "phone": "+201155000666",
        "vehicle_type": "motorcycle",
        "current_location": "Zamalek, Cairo",
        "current_lat": 30.0450,
        "current_lon": 31.2400,
        "status": "available",
        "rating": 4.6,
        "total_deliveries": 198,
    },
    {
        "id": 7,
        "name": "Kareem Nour",
        "phone": "+201155000777",
        "vehicle_type": "car",
        "current_location": "Nasr City, Cairo",
        "current_lat": 30.0800,
        "current_lon": 31.3300,
        "status": "available",
        "rating": 4.3,
        "total_deliveries": 56,
    },
    {
        "id": 8,
        "name": "Waleed Gamal",
        "phone": "+201155000888",
        "vehicle_type": "motorcycle",
        "current_location": "Giza, Cairo",
        "current_lat": 29.9750,
        "current_lon": 31.2650,
        "status": "offline",
        "rating": 4.1,
        "total_deliveries": 34,
    },
]

_next_package_id: int = len(_packages) + 1


# ═══════════════════════════════════════════════════════════════
# HELPER FUNCTIONS — Use these in your endpoints
# ═══════════════════════════════════════════════════════════════

def get_all_packages() -> list[dict]:
    """Return a COPY of all packages.

    Returns:
        list[dict]: All packages in the database.

    Example:
        packages = get_all_packages()
        # [{"id": 1, "tracking_code": "SD-00001", ...}, ...]
    """
    return copy.deepcopy(_packages)


def get_package_by_id(package_id: int) -> dict | None:
    """Find a package by its ID.

    Args:
        package_id: The numeric ID of the package.

    Returns:
        dict: The package if found.
        None: If no package with that ID exists.

    Example:
        pkg = get_package_by_id(1)
        if pkg is None:
            # handle not found
    """
    for p in _packages:
        if p["id"] == package_id:
            return copy.deepcopy(p)
    return None


def save_package(package_data: dict) -> dict:
    """Save a new package to the database.
    Automatically assigns an ID and tracking code.

    Args:
        package_data: Dict with package fields (without id/tracking_code).

    Returns:
        dict: The saved package with generated id and tracking_code.

    Example:
        new_pkg = save_package({
            "sender_name": "Ahmed",
            "recipient_name": "Sara",
            "weight_kg": 2.5,
            ...
        })
        # new_pkg["id"] = 13, new_pkg["tracking_code"] = "SD-00013"
    """
    global _next_package_id
    package_data["id"] = _next_package_id
    package_data["tracking_code"] = f"SD-{_next_package_id:05d}"
    package_data["created_at"] = datetime.now()
    package_data.setdefault("status", "pending")
    package_data.setdefault("assigned_courier_id", None)
    _next_package_id += 1
    _packages.append(package_data)
    return copy.deepcopy(package_data)


def update_package(package_id: int, updates: dict) -> dict | None:
    """Update specific fields of a package.

    Args:
        package_id: The ID of the package to update.
        updates: Dict of fields to update. Only provided keys are changed.

    Returns:
        dict: The updated package if found.
        None: If no package with that ID exists.

    Example:
        updated = update_package(1, {"status": "in_transit", "assigned_courier_id": 3})
    """
    for p in _packages:
        if p["id"] == package_id:
            for key, value in updates.items():
                p[key] = value
            return copy.deepcopy(p)
    return None


def delete_package(package_id: int) -> bool:
    """Delete a package by ID.

    Args:
        package_id: The ID of the package to delete.

    Returns:
        True if the package was found and deleted, False otherwise.
    """
    for i, p in enumerate(_packages):
        if p["id"] == package_id:
            _packages.pop(i)
            return True
    return False


def get_all_couriers() -> list[dict]:
    """Return a COPY of all couriers.

    Returns:
        list[dict]: All couriers in the database.
    """
    return copy.deepcopy(_couriers)


def get_courier_by_id(courier_id: int) -> dict | None:
    """Find a courier by their ID.

    Args:
        courier_id: The numeric ID of the courier.

    Returns:
        dict | None: The courier if found, None otherwise.
    """
    for c in _couriers:
        if c["id"] == courier_id:
            return copy.deepcopy(c)
    return None


def get_available_couriers() -> list[dict]:
    """Return all couriers with status 'available'.

    Returns:
        list[dict]: Only available couriers.
    """
    return copy.deepcopy([c for c in _couriers if c["status"] == "available"])


def update_courier(courier_id: int, updates: dict) -> dict | None:
    """Update specific fields of a courier.

    Args:
        courier_id: The ID of the courier to update.
        updates: Dict of fields to update.

    Returns:
        dict | None: The updated courier if found, None otherwise.
    """
    for c in _couriers:
        if c["id"] == courier_id:
            for key, value in updates.items():
                c[key] = value
            return copy.deepcopy(c)
    return None


# ═══════════════════════════════════════════════════════════════
# LARGE DATASET GENERATOR — Used for performance testing
# ═══════════════════════════════════════════════════════════════

def generate_large_dataset(n: int = 2000) -> list[dict]:
    """Generate a large list of packages for performance testing.
    Intentionally includes ~10% duplicates to test detection.

    Args:
        n: Number of packages to generate (default 2000).

    Returns:
        list[dict]: A large list of package dicts.
    """
    names = [
        "Ahmed Hassan", "Sara Mohamed", "Omar Ali", "Nour Ibrahim",
        "Fatma Youssef", "Khaled Mostafa", "Youssef Tarek", "Mona Adel",
        "Layla Mahmoud", "Hassan Emad", "Tarek Nabil", "Dina Samir",
    ]
    weights = [0.5, 1.0, 2.0, 2.5, 3.0, 5.0, 8.0, 10.0, 15.0, 25.0]
    base_time = datetime.now()
    dataset = []

    for i in range(n):
        sender = random.choice(names)
        recipient = random.choice([n for n in names if n != sender])
        weight = random.choice(weights)

        # Every 10th package is a duplicate of the previous one (same sender, recipient, weight, ~1 min apart)
        if i > 0 and i % 10 == 0:
            prev = dataset[-1]
            sender = prev["sender_name"]
            recipient = prev["recipient_name"]
            weight = prev["weight_kg"]
            created = prev["created_at"] + timedelta(seconds=random.randint(30, 240))
        else:
            created = base_time - timedelta(minutes=random.randint(0, 10000))

        dataset.append({
            "id": i + 1,
            "sender_name": sender,
            "recipient_name": recipient,
            "weight_kg": weight,
            "created_at": created,
        })

    return dataset
