"""
SwiftDrop — Main API
=====================
A fast package delivery platform API.

You just joined SwiftDrop as a Junior Backend Developer.
The project structure, schemas, database, and utilities are all ready.
You only need to write the LOGIC inside the endpoint functions marked with ✏️.

Check the Slides for the detailed requirements of each Ticket!
"""

from fastapi import FastAPI, HTTPException, Query
from fastapi.middleware.cors import CORSMiddleware
from typing import Annotated

import fake_db
from schemas import PackageCreate, StatusUpdate, DeliverySlot
from utils import (
    calculate_distance,
    VALID_TRANSITIONS,
    find_duplicates_optimized,
    benchmark_duplicate_detection,
    select_max_deliveries_optimized,
    benchmark_scheduling,
)

app = FastAPI(title="SwiftDrop API", version="1.0.0")

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_methods=["*"],
    allow_headers=["*"],
)


# ═══════════════════════════════════════════════════════════════
# READY ENDPOINTS — Already built by the previous developer.
# These are done. Study them to understand the patterns.
# ═══════════════════════════════════════════════════════════════

@app.get("/stats")
def get_stats():
    """Dashboard statistics — used by the frontend header cards."""
    packages = fake_db.get_all_packages()
    couriers = fake_db.get_all_couriers()
    return {
        "total_packages": len(packages),
        "in_transit": len([p for p in packages if p["status"] == "in_transit"]),
        "delivered": len([p for p in packages if p["status"] == "delivered"]),
        "pending": len([p for p in packages if p["status"] == "pending"]),
        "cancelled": len([p for p in packages if p["status"] == "cancelled"]),
        "available_couriers": len([c for c in couriers if c["status"] == "available"]),
        "total_couriers": len(couriers),
    }


@app.get("/couriers")
def list_couriers():
    """Get all couriers."""
    return fake_db.get_all_couriers()


@app.get("/couriers/{courier_id}")
def get_courier(courier_id: int):
    """Get a specific courier by ID — notice how we handle 'not found'."""
    courier = fake_db.get_courier_by_id(courier_id)
    if not courier:
        raise HTTPException(status_code=404, detail="Courier not found")
    return courier


@app.delete("/packages/{package_id}")
def delete_package(package_id: int):
    """Delete a package — uses proper error handling."""
    if not fake_db.delete_package(package_id):
        raise HTTPException(status_code=404, detail="Package not found")
    return {"message": "Deleted"}


@app.get("/packages/{package_id}/fee")
def calculate_fee(package_id: int):
    """
    Calculate delivery fee — Real-world business logic example.
    This is how companies implement pricing: tiers + multipliers + surcharges.
    """
    package = fake_db.get_package_by_id(package_id)
    if not package:
        raise HTTPException(status_code=404, detail="Package not found")

    # Weight tier pricing
    weight = package["weight_kg"]
    if weight <= 5:
        base = 30
    elif weight <= 15:
        base = 60
    elif weight <= 30:
        base = 100
    else:
        base = 180

    # Priority multiplier
    multipliers = {"standard": 1.0, "express": 1.5, "same_day": 2.0}
    multiplier = multipliers.get(package["priority"], 1.0)

    # Fragile surcharge
    surcharge = 25 if package["fragile"] else 0

    total = (base * multiplier) + surcharge

    return {
        "package_id": package_id,
        "weight_kg": weight,
        "base_fee": base,
        "priority": package["priority"],
        "priority_multiplier": multiplier,
        "fragile_surcharge": surcharge,
        "total_fee": total,
        "currency": "EGP",
    }


# ╔═══════════════════════════════════════════════════════════════╗
# ║              📋 YOUR TICKETS START HERE                       ║
# ║  Check the Slides for the exact requirements of each Ticket!  ║
# ╚═══════════════════════════════════════════════════════════════╝


# ─────────────────────────────────────────────────────────────
# BONUS #1: Duplicate Detection — optimize in utils.py
# ─────────────────────────────────────────────────────────────
@app.get("/packages/duplicates")
def detect_duplicates():
    """Detect duplicate packages and benchmark naive vs optimized."""
    real_packages = fake_db.get_all_packages()
    real_duplicates = find_duplicates_optimized(real_packages)

    large_dataset = fake_db.generate_large_dataset(2000)
    benchmark = benchmark_duplicate_detection(large_dataset)

    return {
        "real_duplicates": [
            {"package_1_id": d[0], "package_2_id": d[1]} for d in real_duplicates
        ],
        "benchmark": benchmark,
    }


# ─────────────────────────────────────────────────────────────
# TICKET #1: Get Package Details
# Topics: Path Parameters, Error Handling
# ─────────────────────────────────────────────────────────────
@app.get("/packages/{package_id}")
def get_package(package_id: int):
    # ✏️ YOUR CODE HERE
    pass


# ─────────────────────────────────────────────────────────────
# TICKET #2: List & Filter Packages
# Topics: Query Parameters, CRUD (Read)
# ─────────────────────────────────────────────────────────────
@app.get("/packages")
def list_packages(
    city: str | None = None,
    status: str | None = None,
    priority: str | None = None,
    limit: Annotated[int, Query(ge=1, le=100)] = 20,
    offset: Annotated[int, Query(ge=0)] = 0,
):
    # ✏️ YOUR CODE HERE
    pass


# ─────────────────────────────────────────────────────────────
# TICKET #3: Create Package
# Topics: Pydantic Models, Custom Response (201), Error Handling
# ─────────────────────────────────────────────────────────────
@app.post("/packages", status_code=201)
def create_package(data: PackageCreate):
    # ✏️ YOUR CODE HERE
    pass


# ─────────────────────────────────────────────────────────────
# TICKET #4: Update Delivery Status
# Topics: CRUD (Update), Error Handling, Business Logic
# ─────────────────────────────────────────────────────────────
@app.patch("/packages/{package_id}/status")
def update_package_status(package_id: int, body: StatusUpdate):
    # ✏️ YOUR CODE HERE
    pass


# ═══════════════════════════════════════════════════════════════
# BONUS TICKETS — Optimize the functions in utils.py
# The endpoints below are already done. Your task is in utils.py.
# ═══════════════════════════════════════════════════════════════

# ─────────────────────────────────────────────────────────────
# BONUS #2: Max Deliveries Scheduling — optimize in utils.py
# ─────────────────────────────────────────────────────────────
@app.post("/couriers/{courier_id}/max-deliveries")
def max_deliveries(courier_id: int, slots: list[DeliverySlot]):
    """Given a courier's delivery requests, find the max non-overlapping set."""
    courier = fake_db.get_courier_by_id(courier_id)
    if not courier:
        raise HTTPException(status_code=404, detail="Courier not found")

    slots_dict = [s.model_dump() for s in slots]
    result = select_max_deliveries_optimized(slots_dict)
    benchmark = benchmark_scheduling(slots_dict)

    return {
        "courier_id": courier_id,
        "courier_name": courier["name"],
        "total_requests": len(slots),
        "max_deliveries": len(result),
        "selected": result,
        "benchmark": benchmark,
    }
