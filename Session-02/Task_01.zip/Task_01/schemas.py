"""
SwiftDrop — Pydantic Schemas
=============================
These schemas define the shape of data flowing in and out of the API.
STUDENTS: Do NOT modify this file. These schemas are ready to use.
"""

from pydantic import BaseModel, Field, field_validator


class PackageCreate(BaseModel):
    """Schema for creating a new package (POST /packages)."""
    sender_name: str = Field(min_length=2, max_length=100)
    sender_phone: str = Field(min_length=10, max_length=15)
    recipient_name: str = Field(min_length=2, max_length=100)
    recipient_address: str = Field(min_length=5, max_length=300)
    city: str = Field(min_length=2, max_length=50)
    weight_kg: float = Field(gt=0, le=50)
    description: str | None = Field(default=None, max_length=500)
    fragile: bool = False
    priority: str = Field(default="standard")

    @field_validator("priority")
    @classmethod
    def validate_priority(cls, v: str) -> str:
        allowed = {"standard", "express", "same_day"}
        if v not in allowed:
            raise ValueError(f"Priority must be one of: {', '.join(allowed)}")
        return v


class StatusUpdate(BaseModel):
    """Schema for updating a package's delivery status."""
    status: str

    @field_validator("status")
    @classmethod
    def validate_status(cls, v: str) -> str:
        allowed = {"pending", "assigned", "picked_up", "in_transit", "delivered", "cancelled"}
        if v not in allowed:
            raise ValueError(f"Status must be one of: {', '.join(allowed)}")
        return v


class DeliverySlot(BaseModel):
    """Schema for a delivery time slot (Bonus #2)."""
    id: int
    area: str = Field(min_length=2)
    start: str = Field(pattern=r"^\d{2}:\d{2}$", description="HH:MM format")
    end: str = Field(pattern=r"^\d{2}:\d{2}$", description="HH:MM format")
    fee: float = Field(gt=0)
